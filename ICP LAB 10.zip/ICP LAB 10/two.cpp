#include "stabbingLines.h"

void readLines(ifstream& inPutLineFile, Line linesArray[],const int MaxLnsSize, int& numLines){
     int Lid;
     int pointID_one;
     int pointID_two;
     numLines;
     linesArray[numLines];

     while(int i = 0; i < numLines; i++){
         inPutLineFile >> Lid >> pointID_one >> pointID_two;
         linesArray[i] = {Lid,pointID_one,pointID_two};
         
         cout << "Line ID =" << linesArray[i].Lid << "P1 Value =" << linesArray[i].p1 << linesArray[i].p2;
     }
     inPutLineFile.close();
 }



 