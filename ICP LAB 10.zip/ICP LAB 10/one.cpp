#include"stabbingLines.h"

void readPoints(ifstream& inPutPointFile, Point pointsArray[], const int MaxPntsSize, int& numPoints){
    pointsArray[numPoints];
    int a;
    int b;
    int c;

    for(int i = 0; i<numPoints;i++){
        inPutPointFile >> a >> b >> c;
        cout << "pointId = " << pointsArray[i].Pid << "X value =" << pointsArray[i].x1 << "Y value" << pointsArray[i].y1;
    }
    inPutPointFile.close();
}


