#include "stabbingLines.h"

void printLineByCoords(LineId lid, Line linesArray[], const int MaxLnsSize, Point pointsArray[], const int MaxPntsSize){
    linesArray[MaxLnsSize];
    linesArray[MaxPntsSize];

    for(int i = lid ;i < MaxLnsSize; i++){
        Line a =linesArray[i];
        Point ONE =pointsArray[a.p1];
        Point TWO =pointsArray[a.p2];
        
        cout << a.lid << ONE.x1 << ONE.y1 << TWO.x1 << TWO.y1;
    }
}